import UIKit

// MARK: - Задача 3*. К выполнению необязательна. 

enum LinkedList<T> {
    indirect case node (value: T, next: LinkedList<T>)
    case end
}

let list = LinkedList.node(value: 1, next: .node(value: 2, next: .node(value: 3, next: .end)))
