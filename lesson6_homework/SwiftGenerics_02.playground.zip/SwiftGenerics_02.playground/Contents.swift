import UIKit

// MARK: - Задача 2

/* Cоздать систему generic-типов. Типы могут быть свои либо можно использовать предложенный ниже вариант

 Реализовать базовый протокол для контейнеров. Контейнеры должны отвечать, сколько они содержат
 элементов, добавлять новые элементы и возвращать элемент по индексу. На основе базового протокола
 реализовать универсальный связанный список и универсальную очередь (FIFO) в виде структуры или класса.
 */


protocol Container {
    
    associatedtype Item
    
    mutating func append(_ item: Item)
    var count: Int {get}
    subscript(i: Int) -> Item? {get}
}


// Делаем универсальную очередь (FIFO)

struct Queue<T> {
    
    var items = [T]()
    
    mutating func push(_ item: T) {
        items.append(item)
    }
    mutating func pop(_ item: T) {
        items.removeFirst()
    }
}

extension Queue: Container {
    
    typealias Item = T
    
    mutating func append(_ item: T) {
        self.push(item)
    }
    var count: Int {
        return items.count
    }
    subscript(i: Int) -> T? {
        return items[i]
    }
}


// Делаем связанный список

class Node<T> {

    let value: T
    var next: Node?

    init(value: T, next: Node? = nil) {
        self.value = value
        self.next = next
    }
}

class LinkedList<T> {
 
    let head: Node<T>
    var count = 0

        init(node: Node<T>) {
            self.head = node
            count = 1
        }

        convenience init(nodeValue: T) {
            self.init(node: Node<T>(value: nodeValue))
        }

        func addNode(node: Node<T>) {
            var current: Node = self.head
            while current.next != nil {
                current = current.next!
            }
            current.next = node
            count += 1
        }

        func addNode(withValue value: T) {
            self.addNode(node: Node(value: value))
        }
}
   
extension LinkedList: Container {
    
    typealias Item = T
    
    func append(_ item: T) {
        self.addNode(withValue: item)
    }
    
    subscript(index: Int) -> T? {
        let current: Node = self.head
        let counter = 0
        var result: T? = nil
        
        while counter != index + 1 {
            if counter == index {
                result = current.value
            } else {
                return nil
            }
        }
        return result
    }
}





